no declaration on this line
second line
