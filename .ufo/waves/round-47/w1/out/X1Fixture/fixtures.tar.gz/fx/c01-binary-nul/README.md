append-only rules live here
